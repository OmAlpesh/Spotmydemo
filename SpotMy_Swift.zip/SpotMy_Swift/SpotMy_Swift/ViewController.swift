//
//  ViewController.swift
//  SpotMy_Swift
//
//  Created by alpesh patel on 11/21/16.
//  Copyright © 2016 alpesh patel. All rights reserved.
//

import UIKit


class ViewController: UIViewController,RevMobAdsDelegate {

    //MARK:- ibOutLat 
    
    @IBOutlet weak var imgScrollPanal: UIImageView!
    
    @IBOutlet weak var imgTimer: UIImageView!
    
    @IBOutlet weak var imgPrograss: UIImageView!
    
    @IBOutlet weak var imgDifferent1: UIImageView!
    
    @IBOutlet weak var imgDifferent2: UIImageView!
    
    @IBOutlet weak var lblScore: UILabel!
    
    @IBOutlet weak var lblLevel: UILabel!
    
    @IBOutlet weak var lblTimer: UILabel!
    
    @IBOutlet weak var btnMoreCount: UIButton!
    
    @IBOutlet weak var btnRevelCount: UIButton!
    
    @IBOutlet weak var btnFreezeCount: UIButton!
    
    @IBOutlet weak var btnRevel: UIButton!
    
    @IBOutlet weak var btnFreeze: UIButton!
    
    @IBOutlet weak var btnMoreTime: UIButton!
    
    
    @IBOutlet weak var btnPuase: UIButton!
    
    
    @IBOutlet var vcRevMob: RevMobBannerView!
    
    @IBOutlet var pausevw: UIView!
    @IBOutlet var pausePopUP: UIView!
    @IBOutlet var btnResume: UIButton!
    @IBOutlet var btnQuit: UIButton!
    @IBOutlet var btnHome: UIButton!
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    
     //MARK:- variable
    var fullscreen: RevMobFullscreen!
    
    
   //  var img1: UIImageView = UIImageView()
   //  var img2: UIImageView = UIImageView()
    
    // var dot: UIImageView!
   //  var dot1: UIImageView!
     var spot: UIImageView = UIImageView()
     var spot1: UIImageView = UIImageView()
    
     var defectivepoint: CGPoint!
    
    //var arraspectpoints: NSMutableArray!
    var arraspectpoints = [Any]()
    //var arraspectsize: NSMutableArray!
    var arraspectsize = [Any]()
    
    
  // var arrSize: NSMutableArray!
     var arrSize = [Any]()
    
  //  var arrpoints: NSMutableArray!
        var arrpoints = [Any]()
    
    var mainview: UIView = UIView()


    var standardUserDefaults: UserDefaults!
    var ArrGameCoOrdinate = [Any]()
    var StrGid = ""
    var FMquery1 = ""
    var ArrLevel = [Any]()
    var ArrFlagLevel = [Any]()
    var StrflagLevel = ""
    var timer: Timer!
    var temLevel = ""
    var levelTemp = ""
    @IBOutlet var vwProgress: UIImageView!
    //Timer CountDown
    var timerview: UIView = UIView()
    var countDown = 0
    var countDownTimer: Timer = Timer()
    var countDownLabel: UILabel = UILabel()
    //Pause screen outlets...
  
    
    var vdict = [AnyHashable: Any]()
    var Flag_PauseSelected = ""
    
    
    
     //MARK:- block Coding
    
    //Start RevMob code
    let completionBlock: () -> Void = {
        // do something when it successfully starts the session
        RevMobAds.session().showFullscreen();
    }
    let errorBlock: (_ error: Error?) -> Void = {error in
        // check the error
        
    }
    
    
    //MARK:- viewLifeCycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        
        btnFreeze.isUserInteractionEnabled = false
        btnMoreTime.isUserInteractionEnabled = false
        btnRevel.isUserInteractionEnabled = false
        btnPuase.isUserInteractionEnabled = false
        
       
    
        //Alpesh-------------------
        RevMobAds.startSession(withAppID: "55f055153fb1426b0b4d7c31", andDelegate: self)
        RevMobAds.startSession(withAppID: "55f055153fb1426b0b4d7c31", withSuccessHandler: completionBlock
            , andFailHandler: errorBlock)
        
    }

    override func viewWillAppear(_ animated: Bool) {
        
        standardUserDefaults = UserDefaults.standard
     
        Flag_PauseSelected = "NO"
        btnMoreTime.isUserInteractionEnabled = true
        btnFreeze.isUserInteractionEnabled = true
        btnRevel.isUserInteractionEnabled = true
        // Do any additional setup after loading the view.
        
        appDelegate.counter = "0"
        
        
        if CInt(appDelegate.flageTotalScore) != 0 {
            lblScore.text = "\(appDelegate.flageTotalScore)"
        }
        else {
            lblScore.text = ""
        }
        
        self.counterDisplay()
        
        if (UIScreen.main.bounds.size.width) > 568.0 {
            imgDifferent1.layer.masksToBounds = true
            imgDifferent1.layer.cornerRadius = 10.0
            imgDifferent2.layer.masksToBounds = true
            imgDifferent2.layer.cornerRadius = 10.0
        }
        else {
            imgDifferent1.layer.masksToBounds = true
            imgDifferent1.layer.cornerRadius = 13.0
            imgDifferent2.layer.masksToBounds = true
            imgDifferent2.layer.cornerRadius = 13.0
        }

        imgDifferent1.layer.borderColor = UIColor.white.cgColor
        imgDifferent1.layer.borderWidth = 2.0
        imgDifferent2.layer.borderColor = UIColor.white.cgColor
        imgDifferent2.layer.borderWidth = 2.0

     
        
       
        DispatchQueue.main.async {
            
            if self.appDelegate.strDownload == true {
                
            }
            else {
                
                self.temLevel = "\(self.appDelegate.flageLevel)"
            }
            
            self.startCountDown()
        }
        

        
        //self.levelMethod()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    //MARK:- revMobDelegate Method
    
    func loadFullscreen() {
        self.fullscreen = RevMobAds.session().fullscreen()
        self.fullscreen.delegate = self
        self.fullscreen.loadAd()
    }
    
    func revmobSessionIsStarted() {
        //As soon as RevMob SDK is initialized, load a fullscreen ad
        self.loadFullscreen()
    }
    
    func revmobSessionNotStarted(_ error: Error?) {
        
        RevMobAds.startSession(withAppID: "55f055153fb1426b0b4d7c31", andDelegate: self)
    }
    
    func revmobAdDidReceive() {
        //Ad was received. You can show it whenever you want now
        
    }
    
    func revmobAdDisplayed() {
        //Reset adLoaded after ad is displayed
        
    }
    
    func revmobAdDidFailWithError(_ error: Error?) {
        //You might want to limit the number of trials here or try a different ad unit
        self.loadFullscreen()
    }
    
    //MARK:- User-define Game Method
    func findactualpoint(_ originalPt: CGPoint, _imgheight h1: CGFloat, _imgWidth w1: CGFloat) -> CGPoint {
        
        var stPoint: CGPoint = CGPoint()
        
        stPoint.x = (w1 * originalPt.x) / 1200
        stPoint.y = (h1 * originalPt.y) / 850
       
        return stPoint
    }
    
    func findactualsize(_ originalsize: CGSize, _imgheight h1: CGFloat, _imgWidth w1: CGFloat) -> CGSize {
        
        var stsize: CGSize = CGSize()
        
        stsize.height = (w1 * originalsize.height) / 1200
        stsize.width = (h1 * originalsize.width) / 850
       
        return stsize
    }
    
    
    func levelMethod() -> Void {
        
     
       // let tmpNO = 1 + arc4random() % 5
        
        let tmpNO = 1
        
        print("tmpNO:\(tmpNO)")
        
        
        
        for i in 0..<5 {
            
            let path = Bundle.main.path(forResource: "Coordinate", ofType: "plist")!
            
            var dict = [AnyHashable: Any]()
//            
//            
//            if let path = Bundle.main.path(forResource: "Coordinate", ofType: "plist") {
//                
//                if var dict = try? String(contentsOfFile: path) {
//                   
//                }
//            }
            
           // var dict: NSDictionary
            
           
            dict = NSDictionary(contentsOfFile: path)! as! [AnyHashable : Any]
          

            levelTemp = "1"
        
            let X = (dict["X\(levelTemp)\(tmpNO)\(i)"] as! String)
            let Y = (dict["Y\(levelTemp)\(tmpNO)\(i)"] as! String)
            let W = (dict["W\(levelTemp)\(tmpNO)\(i)"] as! String)
            let H = (dict["H\(levelTemp)\(tmpNO)\(i)"] as! String)
            
            let pt = CGPoint(x: CGFloat(CFloat(X)!), y: CGFloat(CFloat(Y)!))
            
           /// arrpoints.addObjects(from: NSValue(pt))
            
            arrpoints.append(pt)
           
            
            
            let sz = CGSize(width: CGFloat(CFloat(W)!), height: CGFloat(CFloat(H)!))
          //  arrSize.addObjects(from: NSValue(sz))
            
             arrSize.append(sz)
            
            
        }
        
        let strimg1 : String?
        let strimg2 : String?
        
       //  strimg1 = "Level_\(levelTemp)_00.png"
      //   strimg2 = "Level_\(levelTemp)\(tmpNO)_01.png"
        
         strimg1 = "Level_\(levelTemp)_00"
         strimg2 = "Level_\(levelTemp)\(tmpNO)_01"
        
        DispatchQueue.main.async {
            self.imgDifferent1.image = UIImage(named: strimg1!)
            self.imgDifferent2.image = UIImage(named: strimg2!)
        }

        self.startGame()
    }
    
    func startGame() {
        
        for i in 0...4 {
            
            var val = arrpoints[i]
            
           // var p = val.cgPoint()
            let p = val as! CGPoint
            
            let pt = self.findactualpoint(p, _imgheight: imgDifferent1.frame.size.height, _imgWidth: imgDifferent1.frame.size.width)

            arraspectpoints.append(NSValue(cgPoint:pt))
            
            val = arrSize[i]
            
          //  var s = val.cgSize()
            let s = val as! CGSize
            
            let st = self.findactualsize(s, _imgheight: imgDifferent1.frame.size.height, _imgWidth: imgDifferent1.frame.size.width)

            arraspectsize.append(NSValue(cgSize: st))
            
            
            // Temp Button add....
            var temBTN: UIButton?
            var temBTN1: UIButton?
            temBTN = UIButton(frame: CGRect(x: CGFloat(pt.x - 5), y: CGFloat(pt.y - 5), width: CGFloat(st.width), height: CGFloat(st.height)))
            temBTN!.tag = i + 1
            temBTN!.addTarget(self, action: #selector(self.pressButton), for: .touchUpInside)
            temBTN1 = UIButton(frame: CGRect(x: CGFloat(pt.x - 5), y: CGFloat(pt.y - 5), width: CGFloat(st.width), height: CGFloat(st.height)))
            temBTN1!.tag = i + 1
            temBTN1!.addTarget(self, action: #selector(self.pressButton), for: .touchUpInside)
            
            temBTN!.backgroundColor = UIColor.clear
            temBTN1!.backgroundColor = UIColor.clear
            
            imgDifferent1.addSubview(temBTN!)
            imgDifferent2.addSubview(temBTN1!)
        }
    }
    
    @IBAction func pressButton(_ sender: Any) {
        print("Tag:\(Int((sender as AnyObject).tag))")
        
        if (UIScreen.main.bounds.size.width) < 568.0 {
            
            self.spot = UIImageView(frame: CGRect(x: CGFloat((sender as AnyObject).frame.origin.x), y: CGFloat((sender as AnyObject).frame.origin.y), width: CGFloat((sender as AnyObject).frame.size.width - 10), height: CGFloat((sender as AnyObject).frame.size.height - 10)))
           
            self.spot1 = UIImageView(frame: CGRect(x: CGFloat((sender as AnyObject).frame.origin.x), y: CGFloat((sender as AnyObject).frame.origin.y), width: CGFloat((sender as AnyObject).frame.size.width - 10), height: CGFloat((sender as AnyObject).frame.size.height - 10)))
        }
        else {
           
            self.spot = UIImageView(frame: CGRect(x: CGFloat((sender as AnyObject).frame.origin.x), y: CGFloat((sender as AnyObject).frame.origin.y), width: CGFloat((sender as AnyObject).frame.size.width), height: CGFloat((sender as AnyObject).frame.size.height)))
           
            self.spot1 = UIImageView(frame: CGRect(x: CGFloat((sender as AnyObject).frame.origin.x), y: CGFloat((sender as AnyObject).frame.origin.y), width: CGFloat((sender as AnyObject).frame.size.width), height: CGFloat((sender as AnyObject).frame.size.height)))
        }
        
        
        self.spot.image = UIImage(named: "spot_ipad.png")!
        imgDifferent2.addSubview(spot)
        
        self.spot1.image = UIImage(named: "spot_ipad.png")!
        imgDifferent1.addSubview(spot1)
        
        
        let soundPath = Bundle.main.path(forResource: "right", ofType: "mp3")!
        
        var soundID = SystemSoundID()
        AudioServicesCreateSystemSoundID((URL(fileURLWithPath: soundPath) as CFURL), &soundID)
        AudioServicesPlaySystemSound(soundID)
        //--------------------------
        let tmpPoint = arraspectpoints[(sender as AnyObject).tag - 1]
     
        let tp = tmpPoint
       
        let pointtp = (tp as AnyObject).cgPointValue
        
        arraspectpoints.append(pointtp!)
        
        print("Points:\(arraspectpoints)")
        let yourBtn = (self.imgDifferent1.viewWithTag((sender as AnyObject).tag)! as! UIButton)
        let yourBtn1 = (self.imgDifferent2.viewWithTag((sender as AnyObject).tag)! as! UIButton)
        
        yourBtn.isHidden = true
        yourBtn1.isHidden = true
        
        self.addTimer()
        
    }
    
    
    func addTimer() {
        
        let straddTimer = "\(Int(CInt(lblTimer.text!)!) + 100)"
        
        if Int(straddTimer)! >= Int(1000) {
            
            lblTimer.text = "1000"
        }
        else {
            
            lblTimer.text = "\(straddTimer)"
        }
    }
    
    func counterDisplay() {
        
        if CInt(appDelegate.strFreezCounter)! > 0 {
            btnFreezeCount.setTitle("\(appDelegate.strFreezCounter)", for: .normal)
            btnFreezeCount.isHidden = false
        }
        else {
            btnFreezeCount.isHidden = true
            btnFreeze.setBackgroundImage(UIImage(named: "btnfreezeoff")!, for: .normal)
        }
        
        if CInt(appDelegate.strMoreTimeCounter)! > 0 {
            btnMoreCount.setTitle("\(appDelegate.strMoreTimeCounter)", for: .normal)
            btnMoreCount.isHidden = false
        }
        else {
            btnMoreCount.isHidden = true
            btnMoreTime.setBackgroundImage(UIImage(named: "btnmoretimeoff")!, for: .normal)
        }
        
        if CInt(appDelegate.strRevelCounter)! > 0 {
            btnRevelCount.setTitle("\(appDelegate.strRevelCounter)", for: .normal)
            btnRevelCount.isHidden = false
        }
        else {
            btnRevelCount.isHidden = true
            btnRevel.setBackgroundImage(UIImage(named: "btnreveloneoff")!, for: .normal)
        }
    }
    
    func startCountDown() {
        
        countDown = 3
        mainview.alpha = 0.5
        self.view.isUserInteractionEnabled = false
        timerview = UIView(frame: CGRect(x: CGFloat(self.view.bounds.size.width / 2 + self.view.bounds.origin.x), y: CGFloat(self.view.bounds.size.height / 2 + self.view.bounds.origin.y), width: CGFloat(200), height: CGFloat(200)))
        timerview.backgroundColor = UIColor.clear
        self.view.addSubview(timerview)
        self.view.bringSubview(toFront: timerview)
        timerview.alpha = 1.0
        
        countDownLabel = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(self.view.frame.size.width), height: CGFloat(self.view.frame.size.height)))
        countDownLabel.textAlignment = .center
        countDownLabel.font = UIFont(name: "BebasNeue", size: CGFloat(75))!

        
        countDownLabel.text = "\(countDown)"
        countDownLabel.isHidden = false
        self.view.addSubview(countDownLabel)
        countDownLabel.textColor = UIColor.yellow
        
        if !(countDownTimer != nil) {
            
            self.countDownTimer = Timer.scheduledTimer(timeInterval: 1.00, target: self, selector: #selector(self.updateTime), userInfo: nil, repeats: true)
        }
        
    }
    
    func updateTime(_ timerParam: Timer) {
        countDownLabel.text = "\(countDown -= 1)"
        //....Animation...
        let animationGroup = CAAnimationGroup()
        animationGroup.duration = 1.0
        let fadeAnimation = CABasicAnimation(keyPath: "opacity")
        fadeAnimation.fromValue = Int(1.0)
        fadeAnimation.toValue = Int(0.0)
        let scaleAnimation = CABasicAnimation(keyPath: "transform.scale")
        scaleAnimation.fromValue = Int(1.0)
        scaleAnimation.toValue = Int(4.0)
        animationGroup.animations = [fadeAnimation, scaleAnimation]
        countDownLabel.layer.add(animationGroup, forKey: "fadeAnimation")
        countDownLabel.layer.opacity = 0.0
        if countDown == -1 {
            countDownLabel.text = "GO"
            animationGroup.isRemovedOnCompletion = true
            //do whatever you want after the countdown
        }
        else if countDown == -2 {
            
            self.clearCountDownTimer()
            
        }
    }
    
    func clearCountDownTimer() {
        
        timerview.removeFromSuperview()
        countDownTimer.invalidate()
       // countDownTimer = nil
        countDownLabel.isHidden = true
       // countDownLabel = nil
        countDownLabel.removeFromSuperview()
        mainview.alpha = 1.0
        
        self.view.isUserInteractionEnabled = true
        
        if (appDelegate.strDownload == true) {
            
        }
        else {
            temLevel = "\(appDelegate.flageLevel)"
        }
        
        btnFreeze.isUserInteractionEnabled = true
        btnMoreTime.isUserInteractionEnabled = true
        btnRevel.isUserInteractionEnabled = true
        btnPuase.isUserInteractionEnabled = true
        
        self.levelcheck()
    }
    
    func levelcheck() {
        
        if (temLevel == "0") {
            
            appDelegate.flageLevel = "\(Int(CInt(appDelegate.flageSubLevel)) + 1)"
            lblLevel.text = "LEVEL 1"
            levelTemp = "1"
            self.levelMethod()
        }
        else if (temLevel == "1") {
            lblLevel.text = "LEVEL 2"
            levelTemp = "2"
            self.levelMethod()
        }
        else if (temLevel == "2") {
            lblLevel.text = "LEVEL 3"
            levelTemp = "3"
            self.levelMethod()
        }
        else if (temLevel == "3") {
            lblLevel.text = "LEVEL 4"
            levelTemp = "4"
            self.levelMethod()
        }
        else if (temLevel == "4") {
            lblLevel.text = "LEVEL 5"
            levelTemp = "5"
            self.levelMethod()
        }
        else if (temLevel == "5") {
            lblLevel.text = "LEVEL 6"
            levelTemp = "6"
            self.levelMethod()
        }
        else if (temLevel == "6") {
            lblLevel.text = "LEVEL 7"
            levelTemp = "7"
            self.levelMethod()
        }
        else if (temLevel == "7") {
            lblLevel.text = "LEVEL 8"
            levelTemp = "8"
            self.levelMethod()
        }
        else if (temLevel == "8") {
            lblLevel.text = "LEVEL 9"
            levelTemp = "9"
            self.levelMethod()
        }
        else if (temLevel == "9") {
            lblLevel.text = "LEVEL 10"
            levelTemp = "10"
            self.levelMethod()
        }
        else if (temLevel == "10") {
            lblLevel.text = "LEVEL 11"
            levelTemp = "11"
            self.levelMethod()
        }
        else if (temLevel == "11") {
            lblLevel.text = "LEVEL 12"
            levelTemp = "12"
            self.levelMethod()
        }
        else if (temLevel == "12") {
            lblLevel.text = "LEVEL 13"
            levelTemp = "13"
            self.levelMethod()
        }
        else if (temLevel == "13") {
            lblLevel.text = "LEVEL 14"
            levelTemp = "14"
            self.levelMethod()
        }
        if (temLevel == "14") {
            lblLevel.text = "LEVEL 15"
            levelTemp = "15"
            self.levelMethod()
        }
        else if (temLevel == "15") {
            lblLevel.text = "LEVEL 16"
            levelTemp = "16"
            self.levelMethod()
        }
        else if (temLevel == "16") {
            lblLevel.text = "LEVEL 17"
            levelTemp = "17"
            self.levelMethod()
        }
        else if (temLevel == "17") {
            lblLevel.text = "LEVEL 18"
            levelTemp = "18"
            self.levelMethod()
        }
        else if (temLevel == "18") {
            lblLevel.text = "LEVEL 19"
            levelTemp = "19"
            self.levelMethod()
        }
        else if (temLevel == "19") {
            lblLevel.text = "LEVEL 20"
            levelTemp = "20"
            self.levelMethod()
        }
        else if (temLevel == "20") {
            lblLevel.text = "LEVEL 1"
            appDelegate.flageLevel = "0"
            levelTemp = "1"
            self.levelMethod()
        }
        
    }
    
    //MARK:- actionMethod
    
    @IBAction func btnRevelTap(_ sender: Any) {
        
        
    }
    @IBAction func btnFreezeTap(_ sender: Any) {
        
        
    }
    @IBAction func btnMoreTimeTap(_ sender: Any) {
        
        
    }
    @IBAction func btnPauseTap(_ sender: Any) {
        
        
    }
       
}

